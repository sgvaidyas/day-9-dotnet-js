$("ul li").click(function(){
    alert($(this).innerText)
})